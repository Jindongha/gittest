from flask import render_template, Flask, request
from apps import app

@app.route('/')
@app.route('/index')
def index():
